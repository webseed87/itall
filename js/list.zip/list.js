﻿export default [
    {
        level: 'LEVEL 1',
        center: '인천 연수송도센터 2관',
        name: '장OO',
        university: '고려대 노어노문학과'
    },
    {
        level: 'LEVEL 2',
        center: '전주 중화산센터',
        name: '이OO',
        university: '전북대 치과대학 / 성균관대 공학계열'
    },

    {
        level: 'LEVEL 3',
        center: '신촌센터 ',
        name: '손OO',
        university: '고려대 전기전자공학부 / 성균관대 소프트웨어학'
    },
    {
        level: 'LEVEL 3',
        center: '인천 연수송도센터 1관 ',
        name: '서OO',
        university: '동국대 식품산업관리학과 / 국민대 국제통상학과'
    },
    {
        level: 'LEVEL 4',
        center: '부산 화명센터  ',
        name: '구OO',
        university: '부산대 한의과대학 / 가천대 한의과대학 '
    },
    {
        level: 'LEVEL 4',
        center: '부산대센터',
        name: '이OO',
        university: '부산대 약학대학'
    },
    {
        level: 'LEVEL 4',
        center: '일산 백마센터',
        name: '신OO',
        university: '이화여대 영어영문학부 / 한국외대 프랑스어학부 <br> 한국외대 영미문학ㆍ문화학과 / 국민대 AI빅데이터융합경영학과 '
    },
    {
        level: 'LEVEL 4',
        center: '강남센터',
        name: '김OO',
        university: '연세대 경제학부 / 한양대 파이낸스경영학과 <br> 중앙대 소프트웨어학부 '
    },
    {
        level: 'LEVEL 4',
        center: '목동센터 2관  ',
        name: '이OO',
        university: '고려대 영어영문학과 / 성균관대 글로벌경영학 <br>  중앙대 경영학'
    },
    {
        level: 'LEVEL 4',
        center: '목동센터 2관  ',
        name: '이OO',
        university: '고려대 영어영문학과 / 성균관대 글로벌경영학 <br>  중앙대 경영학'
    },
    {
        level: 'LEVEL 4',
        center: '전주 중화산센터 ',
        name: '남OO',
        university: '조선대 약학대학 / 제주대 약학대학'
    },
    {
        level: 'LEVEL 4',
        center: '부산 화명센터',
        name: '박OO',
        university: '숙명여대 약학대학'
    },
    {
        level: 'LEVEL 4',
        center: '신림센터',
        name: '한OO',
        university: '중앙대 간호학과(자연) / 서울시립대 환경공학부  <br>  홍익대 서울캠퍼스자율전공(자연·예능)'
    },
    {
        level: 'LEVEL 4',
        center: '파주센터',
        name: '김OO',
        university: '한양대 경제금융학부 / 이화여대 뇌·인지과학부 <br> 중앙대 경영학'
    },
    {
        level: 'LEVEL 4',
        center: '대구 수성구센터 1관',
        name: '김OO',
        university: '서강대 경제학과  / 중앙대 경영학 <br> 연세대 사회복지학과'
    },
    {
        level: 'LEVEL 4',
        center: '송파센터',
        name: '김OO',
        university: '경희대 한의과대학 / 가천대 한의과대학'
    },
    {
        level: 'LEVEL 4',
        center: '목동센터 3관',
        name: '강OO',
        university: '동국대 한의과대학'
    },
    {
        level: 'LEVEL 4',
        center: '동탄센터',
        name: '오OO',
        university: '서울대 체육교육과 / 고려대 체육교육과'
    },
    {
        level: 'LEVEL 4',
        center: '인천 연수송도센터 2관',
        name: '이OO',
        university: '삼육대 약학대학 / 중앙대 약학대학'
    },
    {
        level: 'LEVEL 4',
        center: '강남센터',
        name: '황OO',
        university: '성균관대 글로벌경영'
    },
    {
        level: 'LEVEL 4',
        center: '안양 평촌센터',
        name: '김OO',
        university: '서울대 의과대학 / 한양대 의과대학 <br> 인하대 의과대학'
    },
    {
        level: 'LEVEL 4',
        center: '수원 정자센터',
        name: '채OO',
        university: '성균관대 사회과학계열'
    },
    {
        level: 'LEVEL 4',
        center: '광명센터',
        name: '김OO',
        university: '한양대 컴퓨터소프트웨어학부 / 성균관대 소프트웨어학 <br> 중앙대 소프트웨어학부'
    },
    {
        level: 'LEVEL 4',
        center: '전주 중화산센터',
        name: '국OO',
        university: '전북대 의과대학 / 원광대 의과대학 / 순천대 약학대학'
    },
    {
        level: 'LEVEL 4',
        center: '대치센터',
        name: '김OO',
        university: '서울대 화학부 / 고려대 전기전자공학부 / 중앙대 소프트웨어학부 <br> DGIST / UNIST'
    },
    {
        level: 'LEVEL 4',
        center: '은평서대문센터',
        name: '문OO',
        university: '건국대 국제무역학과 /  한국외대 미디어커뮤니케이션학부'
    },
    {
        level: 'LEVEL 4',
        center: '부산 화명센터',
        name: '정OO',
        university: '건국대 국제무역학과 /  한국외대 미디어커뮤니케이션학부'
    },
    {
        level: 'LEVEL 4',
        center: '대구 수성구센터 1관',
        name: '김OO',
        university: '고려대 컴퓨터학과 / 한양대 반도체공학과 <br> 중앙대 소프트웨어학부'
    },
    {
        level: 'LEVEL 4',
        center: '수원 정자센터',
        name: '김OO',
        university: '한양대 원자력공학과 / 중앙대 전자전기공학부'
    },
    {
        level: 'LEVEL 4',
        center: '구리남양주센터',
        name: '김OO',
        university: '경희대 프랑스어학과 / 한국외대 글로벌자유전공(인문)'
    },
    {
        level: 'LEVEL 4',
        center: '안산센터',
        name: '김OO',
        university: '고려대 기계공학부 / 성균관대 공학계열 <br> 중앙대 전자전기공학부 / DGIST'
    },
    {
        level: 'LEVEL 4',
        center: '송파센터',
        name: '이OO',
        university: '한양대 융합전자공학부 / 한양대 신소재공학부 <br> 중앙대 전자전기공학부 / GIST '
    },
    {
        level: 'LEVEL 4',
        center: '청주센터',
        name: '박OO',
        university: '이화여대 휴먼기계바이오공학부 / 아주대 응용화학생명공학과'
    },
    {
        level: 'LEVEL 4',
        center: '신림센터',
        name: '최OO',
        university: '서울대 바이오시스템·소재학부'
    },
    {
        level: 'LEVEL 4',
        center: '신림센터',
        name: '최OO',
        university: '서울대 바이오시스템·소재학부'
    },
    {
        level: 'LEVEL 4',
        center: '대치센터',
        name: '최OO',
        university: '단국대 체육교육과'
    },
    {
        level: 'LEVEL 4',
        center: '대치센터',
        name: '이OO',
        university: '고려대 화공생명공학과'
    },
    {
        level: 'LEVEL 4',
        center: '인천 청라센터',
        name: '조OO',
        university: '고려대 일어일문학과 / 서강대 경영학부 <br> 중앙대 경영학'
    },
    {
        level: 'LEVEL 4',
        center: '의정부센터',
        name: '이OO',
        university: '중앙대 전자전기공학부'
    },
    {
        level: 'LEVEL 4',
        center: '전주 송천센터',
        name: '임OO',
        university: '원광대 치과대학'
    },
    {
        level: 'LEVEL 4',
        center: '부산대센터',
        name: '김OO',
        university: '경상국립대 의과대학 / 고신대 의과대학'
    },
    {
        level: 'LEVEL 4',
        center: '강남센터',
        name: '배OO',
        university: '아주대 전자공학과 / 경희대 국제학과'
    },
    {
        level: 'LEVEL 4',
        center: '대전 유성센터',
        name: '정OO',
        university: '중앙대 경영학 /  한양대 관광학부'
    },
    {
        level: 'LEVEL 4',
        center: '부천센터',
        name: '김OO',
        university: '고려대 언어학과 / 중앙대 경영학'
    },
    {
        level: 'LEVEL 4',
        center: '부산 경성대센터',
        name: '단OO',
        university: '고려대 바이오시스템의과학부 / 한양대 화학공학과'
    },
    {
        level: 'LEVEL 4',
        center: '부산 센텀센터 1관',
        name: '이OO',
        university: '중앙대 전자전기공학부 / 성균관대 전자전기공학부'
    },
    {
        level: 'LEVEL 4',
        center: '수원 영통점',
        name: '권OO',
        university: '경희대 치과대학'
    },
    {
        level: 'LEVEL 4',
        center: '성북센터',
        name: '송OO',
        university: '고려대 사학과 /  성균관대 글로벌리더학 <br> 중앙대 경영학'
    },
    {
        level: 'LEVEL 4',
        center: '구리남양주센터',
        name: '최OO',
        university: '한양대 국방정보공학과 / 청주교대 초등교육과'
    },
    {
        level: 'LEVEL 4',
        center: '양산센터',
        name: '정OO',
        university: '청주교대 초등교육과 / 부산대 식품영양학과'
    },
    {
        level: 'LEVEL 4',
        center: '대전 유성센터',
        name: '김OO',
        university: '한국교원대 불어 / 공주교대 초등교육과'
    },
    {
        level: 'LEVEL 4',
        center: '제주센터',
        name: '강OO',
        university: '고려대 수학과 /  GIST <br> DGIST / UNIST'
    },
    {
        level: 'LEVEL 4',
        center: '강남센터',
        name: '김OO',
        university: '고려대 바이오의공학부 / 서강대 전자공학과 <br> 중앙대 전자전기공학부'
    },
    {
        level: 'LEVEL 4',
        center: '대구 시지센터',
        name: '장OO',
        university: '서울교대 초등교육과  /  중앙대 경영학 <br> 중앙대 간호학과(인문)'
    },
    {
        level: 'LEVEL 4',
        center: '신림센터',
        name: '황OO',
        university: '인하대 의과대학 /  연세대 의과대학<br> 경희대 의과대학'
    },
]